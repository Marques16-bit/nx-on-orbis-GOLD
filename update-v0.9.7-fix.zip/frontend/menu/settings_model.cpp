// SPDX-License-Identifier: GPL-3.0-or-later
// eden-ps4: what the menu can change. See settings_model.h.

#include <algorithm>

#include "menu/settings_model.h"

namespace Menu {

namespace {

const char* const HeaderComment = "# Escrito pelo menu do NX on Orbis. Pode ser editado a mão. / Written by the menu; hand edits are kept.";

} // Anonymous namespace

const std::vector<Option>& Catalog() {
    // The defaults here are the ones main.cpp sets in ApplyPs4Settings(): keep them in step.
    static const std::vector<Option> catalog = [] {
    std::vector<Option> list = {
        // ---------------------------------------------------------------- Video / GPU
        {"mode", Group::Video, "Modo do console", "Console mode",
         "Portátil renderiza em 720p (mais leve). TV renderiza em 1080p (bem mais pesado).",
         "Handheld renders at 720p (lighter). Docked renders at 1080p (much heavier).",
         {{"handheld", "Portátil (720p)", "Handheld (720p)"}, {"docked", "TV (1080p)", "Docked (1080p)"}}, 0},
        {"resolution", Group::Video, "Escala de resolução", "Resolution scale",
         "Multiplica a resolução interna do jogo. Acima de 1x pesa muito na GPU do PS4.",
         "Multiplies the game's internal resolution. Above 1x is very heavy for the PS4 GPU.",
         {{"0.25", "0,25x", "0.25x"}, {"0.5", "0,5x", "0.5x"}, {"0.75", "0,75x", "0.75x"}, {"1", "1x", "1x"}, {"1.25", "1,25x", "1.25x"},
          {"1.5", "1,5x", "1.5x"}, {"2", "2x", "2x"}}, 3},
        {"speed_limit", Group::Video, "Limitar velocidade", "Speed limit",
         "Desligado deixa o jogo rodar o mais rápido possível (ele pode acelerar).",
         "Off lets the game run as fast as it can (it may speed up).",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"gpu_accuracy", Group::Video, "Precisão da GPU", "GPU accuracy",
         "Baixa é mais rápida (menos sincronizações). Alta corrige efeitos em alguns jogos, mas pesa. Média fica no meio e só existe se esta versão do Eden a tiver (senão o boot.log avisa).",
         "Low is faster (fewer syncs). High fixes effects in some games but is heavier. Medium is in between and exists only if this Eden has it (otherwise boot.log says so).",
         {{"low", "Baixa (rápida)", "Low (fast)"}, {"medium", "Média", "Medium"}, {"high", "Alta", "High"}}, 0},
        {"reactive_flushing", Group::Video, "Flush reativo", "Reactive flushing",
         "Copia dados da GPU para a CPU quando o jogo os lê. Mais preciso, porém mais lento.",
         "Copies GPU data back when the game reads it. More accurate, but slower.",
         {{"off", "Desligado", "Off"}, {"on", "Ligado", "On"}}, 0},
        {"async_shaders", Group::Video, "Shaders assíncronos", "Asynchronous shaders",
         "Compila shaders em segundo plano: menos travadas, mas o Eden PULA os desenhos cujo shader ainda não ficou pronto, e camadas ou efeitos somem por instantes (visto no Super Mario Maker 2). Desligado é o padrão do Eden: o jogo para um pouco na primeira vez e a imagem sai completa.",
         "Compiles shaders in the background: fewer stutters, but Eden SKIPS draws whose shader is not ready yet, so layers or effects vanish for a moment (seen in Super Mario Maker 2). Off is Eden's own default: the game stalls a little the first time and the picture is complete.",
         {{"on", "Ligado", "On"}, {"off", "Desligado (padrão)", "Off (default)"}}, 1},
        {"astc", Group::Video, "Texturas ASTC", "ASTC textures",
         "CPU é o modo mais estável no PS4. GPU e CPU assíncrona são experimentais.",
         "CPU is the most stable mode on the PS4. GPU and async CPU are experimental.",
         {{"cpu", "CPU (estável)", "CPU (stable)"}, {"gpu", "GPU", "GPU"}, {"async", "CPU assíncrona", "Async CPU"}}, 0},
        // 0.8.3: Eden's own recompression (its settings.h: astc_recompression), applied only if this Eden has it.
        {"astc_recompress", Group::Video, "Compressão das texturas ASTC", "ASTC texture compression",
         "O PS4 não lê ASTC: as texturas são decodificadas e guardadas como RGBA8 (4 bytes por pixel). BC3 guarda 1 byte por pixel (1/4 da memória de textura) e BC1 meio byte (1/8, mas o alfa vira tudo-ou-nada). Quem faz a compressão é a CPU, uma vez por textura enviada, e perde um pouco de qualidade (degradês). Experimental: nunca foi tentado num console.",
         "The PS4 cannot read ASTC: the textures are decoded and kept as RGBA8 (4 bytes a pixel). BC3 keeps 1 byte a pixel (1/4 of the texture memory) and BC1 half a byte (1/8, but alpha becomes all-or-nothing). The CPU does the compression, once per uploaded texture, and loses a little quality (gradients). Experimental: never tried on a console.",
         {{"off", "Sem compressão (RGBA8)", "None (RGBA8)"}, {"bc3", "BC3 (1/4 da memória)", "BC3 (1/4 of the memory)"}, {"bc1", "BC1 (1/8 da memória)", "BC1 (1/8 of the memory)"}}, 0},
        {"shader_cache", Group::Video, "Cache de shaders no disco", "Shader cache on disk",
         "Guarda os shaders compilados para as próximas partidas. Desligue só se suspeitar de um cache corrompido.",
         "Keeps compiled shaders for the next runs. Turn it off only if you suspect a corrupt cache.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"shader_preload", Group::Perf, "Cache de shaders carregado ao iniciar", "Shader cache loaded at start",
         "Quanto do cache de shaders do jogo é compilado antes do jogo começar (cerca de 32 KiB por shader). Sem limite é o padrão: o jogo guarda todos os shaders que compilar, como o Cemu, e nada é apagado. Um limite só serve para economizar memória: se o cache passar dele, é guardado como vulkan.bin.bak (e .bak2, .bak3...) e um novo começa. Se o app morrer ao carregar o cache, a próxima partida carrega com uma só thread e, se morrer de novo, guarda o cache e começa vazio.",
         "How much of the game's shader cache is compiled before the game starts (about 32 KiB per shader). No limit is the default: the game keeps every shader it compiles, like Cemu, and nothing is deleted. A limit only saves memory: a cache over it is kept as vulkan.bin.bak (then .bak2, .bak3...) and a new one starts. If the app dies while the cache loads, the next start loads it with a single thread and, if that dies too, keeps the cache and starts empty.",
         {{"0", "Nenhum (cache novo)", "None (new cache)"}, {"128", "Até ~4 MiB", "Up to ~4 MiB"}, {"256", "Até ~8 MiB", "Up to ~8 MiB"}, {"1024", "Até ~32 MiB", "Up to ~32 MiB"},
          {"4096", "Até ~128 MiB", "Up to ~128 MiB"}, {"all", "Sem limite (padrão)", "No limit (default)"}}, 5},
        {"shader_notice", Group::Perf, "Aviso de shaders e memória", "Shader and memory notice",
         "Mostra no canto da tela quantos shaders estão sendo compilados (como o Cemu) e avisa quando a memória direta está quase no fim. Também liga e desliga pelo menu L3 + R3.",
         "Shows in the corner of the screen how many shaders are being compiled (like Cemu) and warns when direct memory is nearly gone. Also toggled from the L3 + R3 menu.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"driver_cache", Group::Perf, "Cache de pipelines do driver", "Driver pipeline cache",
         "O arquivo de cache do próprio driver de vídeo (vulkan_pipelines.bin). Desligar economiza memória e disco, e descarta uma fonte possível de falhas ao carregar shaders; os shaders compilam do zero.",
         "The video driver's own cache file (vulkan_pipelines.bin). Turning it off saves memory and disk and rules out one possible source of crashes while loading shaders; shaders compile from scratch.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        // 0.8.2: less heap while the menu is open (the pictures are decoded into the C heap before the game starts).
        {"covers", Group::Perf, "Capas no menu de jogos", "Covers in the game list",
         "As capas decodificadas ficam na memória (até 64 MiB) enquanto o menu de jogos está aberto, e parte dessa memória pode não voltar ao sistema depois. Só miniaturas guarda só os quadradinhos; Nenhuma não decodifica imagem nenhuma. Vale na próxima vez que o app abrir.",
         "Decoded covers sit in memory (up to 64 MiB) while the game list is open, and part of that memory may not go back to the system afterwards. Thumbnails only keeps just the small tiles; None decodes no picture at all. Applies the next time the app opens.",
         {{"full", "Completas (padrão)", "Full (default)"}, {"thumbs", "Só miniaturas", "Thumbnails only"}, {"off", "Nenhuma", "None"}}, 0},
        {"dyna_state", Group::Video, "Estado dinâmico do Vulkan", "Vulkan dynamic state",
         "Nível das extensões de estado dinâmico (0 a 3). Se o driver falhar, tente um valor menor.",
         "Level of the dynamic-state extensions (0 to 3). If the driver fails, try a lower value.",
         {{"0", "0", "0"}, {"1", "1", "1"}, {"2", "2", "2"}, {"3", "3", "3"}}, 2},
        {"vertex_input_dynamic", Group::Video, "Entrada de vértices dinâmica", "Dynamic vertex input",
         "Extensão do Vulkan. Desligue se houver falhas gráficas ou travamentos.",
         "Vulkan extension. Turn it off if you get graphics glitches or hangs.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        // From Eden's own graphics screen (0.7.4). Each is applied only if this Eden has the setting.
        {"vsync", Group::Video, "Modo de VSync", "VSync mode",
         "Como os quadros vão para a tela. FIFO (ligado) não rasga a imagem. Imediato e Caixa de entrada dependem do driver de vídeo do PS4, que pode ignorá-los: se nada mudar, veja o boot.log.",
         "How frames go to the screen. FIFO (on) does not tear. Immediate and Mailbox depend on the PS4 video driver, which may ignore them: if nothing changes, see boot.log.",
         {{"fifo", "FIFO (ligado)", "FIFO (on)"}, {"mailbox", "Caixa de entrada", "Mailbox"}, {"immediate", "Imediato (desligado)", "Immediate (off)"},
          {"relaxed", "FIFO relaxado", "Relaxed FIFO"}}, 0},
        {"scaling_filter", Group::Video, "Filtro de adaptação da janela", "Window adapting filter",
         "Filtro que ajusta a imagem do jogo ao tamanho da tela (importa quando a resolução interna não é a da tela). Bilinear é o padrão e o mais leve; Bicúbico, FSR e os outros pesam mais na GPU.",
         "The filter that fits the game image to the screen size (it matters when the internal resolution is not the screen's). Bilinear is the default and the lightest; Bicubic, FSR and the others cost more GPU.",
         {{"bilinear", "Bilinear", "Bilinear"}, {"nearest", "Vizinho mais próximo", "Nearest neighbour"}, {"bicubic", "Bicúbico", "Bicubic"},
          {"gaussian", "Gaussiano", "Gaussian"}, {"scaleforce", "ScaleForce", "ScaleForce"}, {"fsr", "AMD FidelityFX Super Resolution", "AMD FidelityFX Super Resolution"},
          {"area", "Área", "Area"}}, 0},
        {"anti_aliasing", Group::Video, "Anti-aliasing", "Anti-aliasing",
         "Suaviza as bordas serrilhadas. FXAA é leve; SMAA é melhor e pesa mais. Custa GPU, que no PS4 é pouca.",
         "Smooths jagged edges. FXAA is light; SMAA looks better and costs more. It costs GPU, which the PS4 has little of.",
         {{"none", "Nenhum", "None"}, {"fxaa", "FXAA", "FXAA"}, {"smaa", "SMAA", "SMAA"}}, 0},
        {"anisotropy", Group::Video, "Filtragem anisotrópica", "Anisotropic filtering",
         "Melhora a qualidade das texturas vistas de ângulo. Padrão deixa o jogo decidir; 16x é o mais nítido.",
         "Improves textures seen at an angle. Default lets the game decide; 16x is the sharpest.",
         {{"default", "Padrão", "Default"}, {"auto", "Automático", "Auto"}, {"2", "2x", "2x"}, {"4", "4x", "4x"}, {"8", "8x", "8x"}, {"16", "16x", "16x"}}, 0},
        {"dma_accuracy", Group::Video, "Precisão do DMA", "DMA accuracy",
         "Controla as operações de DMA. Segura pode corrigir problemas em alguns jogos, mas pode pesar. Na dúvida, deixe em Padrão.",
         "Controls DMA operations. Safe can fix problems in some games but may cost speed. If unsure, keep Default.",
         {{"default", "Padrão", "Default"}, {"unsafe", "Insegura", "Unsafe"}, {"safe", "Segura", "Safe"}}, 0},
        {"sync_memory", Group::Video, "Sincronizar operações de memória", "Sync memory operations",
         "Garante a consistência dos dados entre operações de computação e memória. Pode corrigir problemas em alguns jogos (Unreal Engine 4 é o mais afetado), mas reduz o desempenho.",
         "Keeps data consistent between compute and memory operations. It can fix problems in some games (Unreal Engine 4 is the most affected) but lowers performance.",
         {{"off", "Desligado", "Off"}, {"on", "Ligado", "On"}}, 0},
        {"speed_percent", Group::Video, "Porcentagem do limite de velocidade", "Speed limit percentage",
         "Velocidade máxima da emulação quando o limite de velocidade está ligado. 100% é o normal; menos deixa o jogo mais lento, mais deixa mais rápido.",
         "Top emulation speed while the speed limit is on. 100% is normal; lower slows the game, higher speeds it up.",
         {{"50", "50%", "50%"}, {"75", "75%", "75%"}, {"100", "100%", "100%"}, {"150", "150%", "150%"}, {"200", "200%", "200%"}}, 2},
        // 0.8.2: Eden's own option, applied only if this Eden has the setting (eden_settings.h). Not tried on a console.
        {"async_presentation", Group::Video, "Apresentação assíncrona", "Asynchronous presentation",
         "Experimental. Mostra os quadros por uma thread separada (opção do Eden, desligada nos PCs): pode tirar um pouco de trabalho da thread da GPU. No PS4 a apresentação passa pelo driver de vídeo e pelo gancho do HUD, então pode causar piscar, quadros repetidos ou travar. Nunca foi testada num console: ligue só para comparar.",
         "Experimental. Shows frames from a separate thread (an Eden option, off on PCs): it may take a little work off the GPU thread. On the PS4 presentation goes through the video driver and the HUD hook, so it may cause flicker, repeated frames or hangs. Never tried on a console: turn it on only to compare.",
         {{"off", "Desligada", "Off"}, {"on", "Ligada (experimental)", "On (experimental)"}}, 0},
        // ---------------------------------------------------------------- CPU and memory
        {"cpu_accuracy", Group::Cpu, "Precisão da CPU", "CPU accuracy",
         "Rápida usa ponto flutuante reduzido (mais velocidade). Automática e Precisa são mais fiéis e mais lentas.",
         "Fast uses reduced-precision floating point (more speed). Auto and Accurate are more faithful and slower.",
         {{"unsafe", "Rápida", "Fast"}, {"auto", "Automática", "Auto"}, {"accurate", "Precisa", "Accurate"}}, 0},
        {"multicore", Group::Cpu, "Multinúcleo", "Multicore",
         "Emula os 4 núcleos da CPU do Switch em threads separadas. Desligar é bem mais lento.",
         "Emulates the Switch's 4 CPU cores on separate threads. Turning it off is much slower.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"vram", Group::Cpu, "Uso de VRAM", "VRAM usage",
         "Conservador usa menos memória de vídeo. Agressivo guarda mais texturas e pode faltar memória.",
         "Conservative uses less video memory. Aggressive keeps more textures and may run out.",
         {{"conservative", "Conservador", "Conservative"}, {"aggressive", "Agressivo", "Aggressive"}}, 0},
        {"memory_profile", Group::Cpu, "Perfil de memória do console", "Console memory profile",
         "Escolhe a arena do driver, o cache de shaders carregado ao iniciar e o cache do driver conforme a memória que o seu PS4 dá ao app. Automático mede (a aba Sistema mostra); os outros forçam um perfil. Rígido é o mais econômico: mantém todas as imagens da GPU dentro da arena (experimental). Uma arena, um cache de shaders ou um cache do driver diferente do padrão, escolhido à mão, vale mais que o perfil.",
         "Picks the driver arena, the shader cache loaded at start and the driver cache from the memory your PS4 gives the app. Auto measures it (the System tab shows it); the others force a profile. Strict is the most frugal: it keeps every GPU image inside the arena (experimental). An arena, shader cache or driver cache set by hand to a non-default value wins over the profile.",
         {{"auto", "Automático", "Auto"}, {"roomy", "Folgado (Pro medido)", "Roomy (measured Pro)"}, {"standard", "Padrão", "Standard"},
          {"tight", "Apertado (Fat/Slim)", "Tight (Fat/Slim)"}, {"strict", "Rígido (experimental)", "Strict (experimental)"}}, 0},
        {"memory_action", Group::Cpu, "Quando a memória ficar crítica", "When memory turns critical",
         "O app vigia o maior bloco livre de memória direta (é ele que acaba antes do crash) e avisa no canto da tela, com a velocidade da queda. Aviso só mostra o texto. Pausar (padrão desde a 0.8.4) também pausa o jogo antes do fim, para você escolher continuar, reiniciar ou sair (precisa da sobreposição de vídeo ligada).",
         "The app watches the largest free block of direct memory (it is what runs out before a crash) and warns in the screen corner with the speed of the fall. Warn only shows the text. Pause (the default since 0.8.4) also pauses the game before the end so you can choose to continue, restart or leave (needs the video overlay on).",
         {{"warn", "Só avisar", "Warn only"}, {"pause", "Avisar e pausar (padrão)", "Warn and pause (default)"}}, 1},
        // 0.9.0: from Eden4 (an unofficial PS4 port of Eden), which keeps its C heap in this pool. 0.9.1: on by default.
        {"sysflex_mib", Group::Cpu, "RAM extra (memória flexível do sistema)", "Extra RAM (system flexible memory)",
         "O PS4 tem um segundo pool de memória, a memória flexível do sistema, fora dos ~4,5 GiB de memória direta que acabam nos jogos grandes. Com esta opção a RAM do jogo usa até N MiB dele antes da memória direta, e sobra mais memória direta livre. Cada jogo reage de um jeito: se um jogo não abre ou fecha sozinho, tente um valor menor (ou Desligado); se faltar memória, tente um maior. Dá para ajustar só para um jogo (R2 na lista). O app mede o pool e deixa 128 MiB para o sistema; Automático (padrão) usa até 1536 MiB. Depois de uma partida que morreu antes de desenhar, o modo seguro limita a 512 MiB. Vale na próxima partida.",
         "The PS4 has a second memory pool, the system flexible memory, outside the ~4.5 GiB of direct memory that big games run out of. With this option the game's RAM uses up to N MiB of it before direct memory, so more direct memory stays free. Every game reacts in its own way: if a game does not open or closes by itself, try a lower value (or Off); if it runs out of memory, try a higher one. It can be set for one game only (R2 in the list). The app measures the pool and leaves 128 MiB to the system; Automatic (the default) uses up to 1536 MiB. After a start that died before drawing, safe mode limits it to 512 MiB. Applies on the next game start.",
         {{"auto", "Automático (padrão)", "Automatic (default)"}, {"off", "Desligado", "Off"}, {"256", "Até 256 MiB", "Up to 256 MiB"},
          {"512", "Até 512 MiB (testado)", "Up to 512 MiB (tested)"}, {"768", "Até 768 MiB", "Up to 768 MiB"}, {"1024", "Até 1024 MiB", "Up to 1024 MiB"},
          {"1536", "Até 1536 MiB", "Up to 1536 MiB"}, {"2048", "Até 2048 MiB (máximo)", "Up to 2048 MiB (maximum)"}}, 0},
        {"env:ORBIS_ARENA_MIB", Group::Cpu, "Arena do driver de vídeo", "Video driver arena",
         "Memória reservada ao driver (MiB). Mais evita erros de memória de vídeo, mas sobra menos para o jogo. Sem escolha aqui, o perfil de memória decide (1280 num PS4 Pro como o medido); a aba Sistema mostra o valor em uso. Evite 1024: uma partida de Super Mario Maker 2 com ela morreu ao carregar os shaders.",
         "Memory reserved for the driver (MiB). More avoids video-memory errors but leaves less for the game. With no choice here the memory profile decides (1280 on a PS4 Pro like the one measured); the System tab shows the value in use. Avoid 1024: a Super Mario Maker 2 start with it died loading the shaders.",
         {{"1024", "1024 MiB", "1024 MiB"}, {"1152", "1152 MiB", "1152 MiB"}, {"1280", "1280 MiB", "1280 MiB"}, {"1536", "1536 MiB", "1536 MiB"},
          {"1792", "1792 MiB", "1792 MiB"}}, 2},
        {"env:ORBIS_VRAM_GARLIC", Group::Cpu, "Texturas dentro da arena", "Textures inside the arena",
         "Experimental, último recurso: mantém imagens na arena do driver em vez de memória extra. Gasta menos memória direta, mas o driver avisa que custa cerca de 2/3 da velocidade de GPU, e pode ser parte de efeitos gráficos errados: se um jogo aparecer com texturas estranhas, teste com isto desligado.",
         "Experimental, last resort: keeps images in the driver's arena instead of extra memory. Uses less direct memory, but the driver warns it costs about 2/3 of the GPU speed, and it may be part of wrong graphics: if a game shows odd textures, try it off.",
         {{"1", "Desligado (padrão)", "Off (default)"}, {"0", "Ligado (experimental)", "On (experimental)"}}, 0},
        {"skip_cpu_invalidation", Group::Cpu, "Ignorar invalidação interna da CPU", "Skip inner CPU invalidation",
         "Ignora certas invalidações de cache do lado da CPU durante atualizações de memória: usa menos CPU (o ponto fraco do PS4), mas pode causar falhas ou travamentos em alguns jogos. Experimental.",
         "Skips some CPU-side cache invalidations during memory updates: uses less CPU (the PS4's weak point) but may cause glitches or hangs in some games. Experimental.",
         {{"off", "Desligado", "Off"}, {"on", "Ligado (experimental)", "On (experimental)"}}, 0},
        // 0.8.2: two Eden options that change what the game READS from the emulated CPU, not how much CPU the PS4 has.
        {"cpu_clock", Group::Cpu, "Relógio da CPU emulada", "Emulated CPU clock",
         "Experimental. O relógio da CPU do Switch que o JOGO lê: Normal 1020 MHz, Impulso 1734 MHz, Overclock 2040 MHz (valores do Eden). NÃO dá mais CPU ao PS4: só muda a hora que o jogo enxerga. Jogos que limitam o próprio FPS por tempo podem rodar mais soltos; outros ficam com som ou física acelerados, ou travam. Teste jogo por jogo.",
         "Experimental. The Switch CPU clock the GAME reads: Normal 1020 MHz, Boost 1734 MHz, Overclock 2040 MHz (Eden's values). It does NOT give the PS4 more CPU: it only changes the time the game sees. Games that cap their own FPS by time may run freer; others get fast audio or physics, or hang. Try it game by game.",
         {{"normal", "Normal", "Normal"}, {"boost", "Impulso (experimental)", "Boost (experimental)"}, {"overclock", "Overclock (experimental)", "Overclock (experimental)"}}, 0},
        {"cpu_ticks", Group::Cpu, "Ticks de CPU personalizados", "Custom CPU ticks",
         "Experimental. Troca a contagem de ciclos que a CPU emulada soma a cada trecho de código por um número fixo (opção do Eden), o que muda de quanto em quanto tempo as threads do jogo voltam ao agendador. O Eden indica de 77 a 21000 e avisa que pode travar o jogo. Não se sabe qual valor ajuda neste PS4: teste um de cada vez e veja o FPS no HUD.",
         "Experimental. Replaces the cycle count the emulated CPU adds after each stretch of code with a fixed number (an Eden option), which changes how often the game's threads return to the scheduler. Eden suggests 77 to 21000 and warns it may hang the game. Which value helps on this PS4 is not known: try one at a time and watch the FPS on the HUD.",
         {{"off", "Desligado", "Off"}, {"1000", "1000", "1000"}, {"4000", "4000", "4000"}, {"16000", "16000 (padrão do Eden)", "16000 (Eden's default)"}, {"21000", "21000", "21000"}}, 0},
        // 0.9.6: thread placement (frontend/thread_placement.h). Not a guess about the game: a guess about the console's scheduler, so it is a switch.
        {"cpu_affinity", Group::Cpu, "Núcleos da CPU fixos", "Pinned CPU cores",
         "Cada uma das 4 threads que rodam os núcleos do Switch fica presa a um núcleo do PS4 só dela, e as demais (GPU, trabalhador do Vulkan, áudio, serviços, compilador de shaders) dividem os núcleos que sobram. Assim o sistema não troca um núcleo do jogo de lugar no meio do quadro. É um palpite sobre o agendador do PS4, não uma certeza: se o FPS do jogo ficar menor do que com \"Desligado\", deixe desligado. Vale para o próximo jogo que abrir. O boot.log mostra que núcleos o console deixou usar e em qual cada thread parou. Depois de uma queda ao abrir, o app desliga sozinho.",
         "Each of the 4 threads that run the Switch's cores is tied to a PS4 core of its own, and the others (GPU, Vulkan worker, audio, services, shader builders) share the cores that are left. That way the system does not move a game core around in the middle of a frame. It is a guess about the PS4's scheduler, not a certainty: if a game's FPS is lower than with \"Off\", leave it off. Applies from the next game you open. boot.log shows which cores the console let the app use and which core each thread ended up on. After a start that died while opening, the app switches it off by itself.",
         {{"auto", "Automático (padrão)", "Automatic (default)"}, {"off", "Desligado", "Off"}}, 0},
        // 0.9.2: the JIT pack (patches/eden-jit/). The effect of Eden4's page reuse, written for Eden's own page table.
        {"jit_page_reuse", Group::Cpu, "JIT: reaproveitar a busca de página", "JIT: reuse page lookups",
         "Obrigatória (escondida no menu): o JIT procura a página de memória uma vez para um grupo de acessos próximos, em vez de uma vez por acesso. Ligada por padrão desde a 0.9.5; depois de duas quedas seguidas num jogo o app desliga sozinho (modo seguro). O boot.log diz se esta versão tem o pacote do JIT e quantos grupos foram formados.",
         "Mandatory (hidden in the menu): the JIT looks a memory page up once for a group of nearby accesses instead of once per access. On by default since 0.9.5; after two deaths in a row in one game the app switches it off by itself (safe mode). boot.log says whether this build has the JIT pack and how many groups were formed.",
         {{"on", "Ligado (padrão)", "On (default)"}, {"off", "Desligado", "Off"}}, 0},
        {"jit_direct_table", Group::Cpu, "JIT: tabela de páginas direta", "JIT: direct page table",
         "Obrigatória (escondida no menu): guarda, ao lado da tabela de páginas do Eden, uma cópia já decodificada: 4 instruções a menos por acesso à memória do jogo. Usa um pouco mais de memória (8 bytes por página de 4 KiB mapeada). Ligada por padrão desde a 0.9.5; o modo seguro a desliga depois de duas quedas seguidas num jogo. O boot.log diz se esta versão tem essa parte.",
         "Mandatory (hidden in the menu): keeps, beside Eden's page table, a copy that is already decoded: 4 instructions fewer per guest memory access. It uses a little more memory (8 bytes per mapped 4 KiB page). On by default since 0.9.5; safe mode switches it off after two deaths in a row in one game. boot.log says whether this build has that part.",
         {{"on", "Ligado (padrão)", "On (default)"}, {"off", "Desligado", "Off"}}, 0},
        {"arena_align", Group::Cpu, "Arena do driver numa janela de 4 GiB", "Driver arena inside one 4 GiB window",
         "Obrigatória (escondida no menu): o driver gráfico pega um bloco de memória (a arena) e o console escolhe o endereço. Se o bloco cruza um múltiplo de 4 GiB, só a parte de baixo serve para os shaders e descritores (ponteiros de 32 bits). No teste do Mario Odyssey a arena de 1536 MiB deixou 643 MiB assim, o driver ficou sem espaço de 32 bits aos 160 s e o jogo caiu; o endereço muda a cada início, por isso às vezes o jogo passava. Ligada, o app reserva endereços até achar um lugar que cabe numa janela só e então deixa o driver pedir a arena (a memória em si não muda). Desligada pelo modo seguro depois de uma queda. O boot.log diz onde o console ia pôr a arena e onde ela ficou.",
         "Mandatory (hidden in the menu): the graphics driver takes one block of memory (the arena) and the console picks its address. If the block crosses a multiple of 4 GiB, only the lower part can serve shaders and descriptors (32-bit pointers). In the Super Mario Odyssey test the 1536 MiB arena left 643 MiB of that, the driver ran out of 32-bit space at 160 s and the game died; the address changes at every start, which is why the game sometimes passed. On, the app reserves address space until it finds a place that fits in one window and then lets the driver ask for the arena (the memory itself does not change). Switched off by safe mode after a death. boot.log says where the console was going to put the arena and where it went.",
         {{"on", "Ligado (padrão)", "On (default)"}, {"off", "Desligado", "Off"}}, 0},
        {"jit_cache_commit", Group::Cpu, "JIT: memória do cache sob demanda", "JIT: cache memory as needed",
         "O cache de código do JIT de cada núcleo era um bloco de memória direta tomado inteiro ao abrir o jogo (4 núcleos x 256 MiB = 1 GiB, para um código que ocupa algumas dezenas de MiB). No teste do Mario Odyssey a memória direta livre caiu de 1242 MiB para 44 MiB em 90 s e o jogo caiu; esse GiB parado era a maior fatia. Agora, com \"Sob demanda\" (o padrão), só o endereço é reservado e a memória direta é tomada em passos de 2 MiB conforme o JIT escreve código: o tamanho do cache vira só um teto. \"Inteiro\" volta ao jeito de antes. Depois de uma queda ao abrir, o app usa Inteiro sozinho. O boot.log mostra quanta memória os caches seguram. Vale para o próximo jogo que abrir.",
         "Each core's JIT code cache used to be one block of direct memory taken whole when the game opened (4 cores x 256 MiB = 1 GiB, for code that is a few tens of MiB). In the Mario Odyssey test the free direct memory fell from 1242 MiB to 44 MiB in 90 s and the game died; that idle GiB was the biggest slice. Now, with \"As needed\" (the default), only the address range is reserved and direct memory is taken in 2 MiB steps as the JIT writes code: the cache size is only a ceiling. \"Whole\" is the way it was. After a start that died while opening, the app uses Whole by itself. boot.log shows how much memory the caches hold. Applies from the next game you open.",
         {{"lazy", "Sob demanda (padrão)", "As needed (default)"}, {"full", "Inteiro (o de antes)", "Whole (as before)"}}, 0},
        {"jit_cache_mib", Group::Cpu, "JIT: cache de código por núcleo", "JIT: code cache per core",
         "Quando o cache de código do JIT enche, ele é esvaziado inteiro e todos os blocos são traduzidos de novo: no PS4 isso aparece como uma travada de 1 a 6 segundos, seguida de FPS baixo até tudo ser traduzido outra vez (no teste do Mario vs. Donkey Kong, com 32 MiB, o cache foi esvaziado 6 vezes em 200 s). Desde a 0.9.7 a memória do cache é tomada conforme o código cresce, então o tamanho é só um teto e um teto grande não custa nada até o código chegar nele: Automático usa 256 MiB por núcleo num PS4 com memória de sobra (4,3 GiB ou mais de memória direta) e 128 MiB nos outros. Com \"JIT: memória do cache sob demanda\" em Inteiro, ou depois de uma queda ao abrir, vale o jeito antigo: 64 MiB (ou 32 sem folga) e a memória inteira tomada ao abrir o jogo (4 núcleos: 128 MiB viram 512 MiB). O boot.log conta quantas vezes o cache foi esvaziado e quantos blocos o JIT traduziu a cada 10 s. Vale para o próximo jogo que abrir.",
         "When the JIT's code cache fills up it is emptied whole and every block is translated again: on the PS4 that shows as a stall of 1 to 6 seconds, followed by low FPS until everything is translated again (in the Mario vs. Donkey Kong test, at 32 MiB, the cache was emptied 6 times in 200 s). Since 0.9.7 the cache's memory is taken as the code grows, so the size is only a ceiling and a big ceiling costs nothing until the code reaches it: Automatic uses 256 MiB per core on a PS4 with memory to spare (4.3 GiB or more of direct memory) and 128 MiB on others. With \"JIT: cache memory as needed\" set to Whole, or after a start that died while opening, the old way applies: 64 MiB (or 32 when tight) and all the memory taken when the game opens (4 cores: 128 MiB becomes 512 MiB). boot.log counts how often the cache was emptied and how many blocks the JIT translated every 10 s. Applies from the next game you open.",
         {{"auto", "Automático (teto de 256 MiB, ou 128)", "Automatic (256 MiB ceiling, or 128)"}, {"32", "32 MiB (o de antes)", "32 MiB (as before)"}, {"64", "64 MiB", "64 MiB"},
          {"128", "128 MiB", "128 MiB"}, {"256", "256 MiB", "256 MiB"}}, 0},
        // ---------------------------------------------------------------- Advanced
        {"bgra", Group::Advanced, "Correção de cor B8G8R8A8", "B8G8R8A8 colour fix",
         "Corrige vermelho e azul trocados nas texturas. Se as cores do jogo estiverem trocadas (céu rosa, chão azul), use Automático ou Desligado.",
         "Fixes swapped red and blue in textures. If a game's colours are swapped (pink sky, blue ground), use Auto or Off.",
         {{"auto", "Automático", "Auto"}, {"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"a2b10", Group::Advanced, "Correção A2B10G10R10", "A2B10G10R10 fix",
         "Correção de texturas de 10 bits, decidida por um teste ao iniciar.",
         "Fix for 10-bit textures, decided by a test at startup.",
         {{"auto", "Automático", "Auto"}, {"off", "Desligado", "Off"}}, 0},
        {"rg", Group::Advanced, "Correção R8G8", "R8G8 fix",
         "Corrige vermelho e verde trocados em texturas de 2 canais. Automático decide por um teste.",
         "Fixes swapped red and green in 2-channel textures. Auto decides from a test.",
         {{"auto", "Automático", "Auto"}, {"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"swizzle", Group::Advanced, "Teste de mapeamento", "Mapping self-test",
         "Roda um teste de componentes no início. Só para diagnóstico.",
         "Runs a component-mapping test at startup. Diagnostics only.",
         {{"off", "Desligado", "Off"}, {"test", "Rodar teste", "Run test"}}, 0},
        {"colour_swap", Group::Advanced, "Trocar vermelho e azul na tela", "Swap red and blue on the screen",
         "Troca vermelho e azul na saída de vídeo, para o céu azul não sair rosa. Desligue se as cores já estiverem certas.",
         "Swaps red and blue in the video output, so the blue sky does not come out pink. Turn it off if the colours are already right.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"hud", Group::Perf, "HUD de desempenho", "Performance HUD",
         "Mostra FPS, núcleos de CPU em uso, memória e temperatura sobre o jogo. Também liga e desliga pelo menu L3 + R3.",
         "Shows FPS, CPU cores in use, memory and temperature over the game. Also toggled from the L3 + R3 menu.",
         {{"off", "Desligado", "Off"}, {"on", "Ligado", "On"}}, 0},
        {"hud_size", Group::Perf, "Tamanho do HUD", "HUD size",
         "Normal ou pequeno (metade do tamanho).", "Normal or small (half the size).",
         {{"normal", "Normal", "Normal"}, {"small", "Pequeno", "Small"}}, 0},
        {"hud_position", Group::Perf, "Posição do HUD", "HUD position",
         "Canto de cima da tela onde o HUD aparece.", "The top corner of the screen the HUD is drawn in.",
         {{"left", "Esquerda", "Left"}, {"right", "Direita", "Right"}}, 0},
        {"overlay", Group::Perf, "Sobreposição de vídeo", "Video overlay",
         "O gancho do vídeo: HUD, menu L3 + R3 e troca de cores. Desligue se um jogo não abrir e você suspeitar dele.",
         "The video hook: HUD, L3 + R3 menu and colour swap. Turn it off if a game will not open and you suspect it.",
         {{"on", "Ligada", "On"}, {"off", "Desligada", "Off"}}, 0},
        {"overlay_draw", Group::Perf, "Desenhar HUD e menu sobre o jogo", "Draw the HUD and menu over the game",
         "Desligado deixa só a troca de cores: o HUD e o menu L3 + R3 não aparecem. Use para ver se o desenho sobre o jogo causa tela preta ou falhas gráficas.",
         "Off keeps only the colour swap: the HUD and the L3 + R3 menu do not show. Use it to see whether drawing over the game causes a black screen or glitches.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"overlay_mode", Group::Perf, "Desenho do HUD e do menu (anti-piscar)", "HUD and menu drawing (anti-flicker)",
         "Contínuo mantém o HUD, o aviso e o menu L3 + R3 em todos os quadros do vídeo e os redesenha no instante em que o jogo pinta por cima: é o que acaba com o piscar (visto no Super Mario Maker 2). Clássico é o desenho da 0.7.3: uma vez por quadro, pode piscar.",
         "Keep-alive holds the HUD, the notice and the L3 + R3 menu in every video frame and redraws them the moment the game paints over them: this is what stops the flicker (seen in Super Mario Maker 2). Classic is the 0.7.3 drawing: once per frame, it can flicker.",
         {{"keepalive", "Contínuo (sem piscar)", "Keep-alive (no flicker)"}, {"classic", "Clássico (0.7.3)", "Classic (0.7.3)"}}, 0},
        {"overlay_poll", Group::Perf, "Verificação do HUD (ms)", "HUD check interval (ms)",
         "Modo contínuo: de quanto em quanto tempo o app confere se o jogo pintou por cima do HUD. 1 é o mais firme e usa um pouco mais de CPU; 8 usa menos CPU e pode deixar escapar um quadro sem HUD.",
         "Keep-alive mode: how often the app checks whether the game painted over the HUD. 1 is the firmest and uses a little more CPU; 8 uses less CPU and may let a frame through without the HUD.",
         {{"1", "1", "1"}, {"2", "2", "2"}, {"4", "4", "4"}, {"8", "8", "8"}}, 0},
        {"overlay_flip_stamp", Group::Perf, "Desenhar também na hora do quadro", "Also draw at the moment of the frame",
         "Modo contínuo: além da verificação, desenha o HUD dentro da própria chamada que mostra o quadro, então um quadro que a GPU já terminou nunca sai sem ele. Desligue só para testar.",
         "Keep-alive mode: besides the checks, draws the HUD inside the very call that shows the frame, so a frame the GPU already finished never goes out without it. Turn it off only to test.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"overlay_delay", Group::Perf, "Espera antes de desenhar o HUD (ms)", "Wait before drawing the HUD (ms)",
         "Só no modo Clássico: tempo que a GPU tem para terminar o quadro antes de o HUD e o menu serem desenhados nele. Se o HUD ainda piscar, aumente; se ele aparecer atrasado, diminua.",
         "Classic mode only: how long the GPU gets to finish a frame before the HUD and menu are drawn into it. If the HUD still flickers, raise it; if it shows late, lower it.",
         {{"0", "0", "0"}, {"1", "1", "1"}, {"2", "2", "2"}, {"4", "4", "4"}, {"8", "8", "8"}}, 2},
        {"profile", Group::Advanced, "Perfilador no log", "Profiler in the log",
         "Registra no boot.log onde a CPU gasta tempo. Útil para relatar problemas.",
         "Records in boot.log where the CPU spends time. Useful for bug reports.",
         {{"on", "Ligado", "On"}, {"off", "Desligado", "Off"}}, 0},
        {"auto_stub", Group::Advanced, "Usar Auto Stub", "Use auto stub",
         "Preenche automaticamente serviços e funções que faltam. Pode ajudar um jogo que para por falta de um serviço, mas também causa falhas e instabilidade. Só para testar.",
         "Fills in missing services and functions automatically. It can help a game that stops for lack of a service, but also causes crashes and instability. For testing only.",
         {{"off", "Desligado", "Off"}, {"on", "Ligado (experimental)", "On (experimental)"}}, 0},
        // ---------------------------------------------------------------- System
        {"language", Group::System, "Idioma do menu", "Menu language",
         "Idioma dos textos deste menu.", "Language of this menu's texts.",
         {{"pt", "Português", "Português"}, {"en", "English", "English"}}, 0},
        {"menu_theme", Group::System, "Cor do menu", "Menu colour",
         "Cor do menu: azul (padrão), verde, roxo, laranja, rosa, vermelho ou cinza. Vale já, e também no HUD e no menu do jogo.",
         "Colour of the menu: blue (default), green, purple, orange, pink, red or grey. Applies at once, and to the HUD and the in-game menu too.",
         {{"blue", "Azul", "Blue"}, {"green", "Verde", "Green"}, {"purple", "Roxo", "Purple"}, {"orange", "Laranja", "Orange"},
          {"pink", "Rosa", "Pink"}, {"red", "Vermelho", "Red"}, {"grey", "Cinza", "Grey"}}, 0},
        // 0.9.5 (zip 5): the menu's own sounds. Made by the program, no files; they stop before a game starts (the game gets the
        // audio port). Only the menu: nothing here touches the game's audio.
        {"menu_audio", Group::System, "Som do menu", "Menu sound",
         "Música ambiente e sons ao mover, escolher, voltar e iniciar um jogo. \"Só sons\" tira a música; \"Desligado\" deixa o menu mudo. Só vale no menu: o áudio do jogo não muda. Se o app travar ao abrir o áudio do menu, ele fica mudo na vez seguinte (apague menu_audio.marker na pasta do app para tentar de novo).",
         "Ambient music and sounds when moving, choosing, going back and starting a game. \"Sounds only\" drops the music; \"Off\" keeps the menu silent. The menu only: the game's audio does not change. If the app hangs while opening the menu's audio, it stays silent the next time (delete menu_audio.marker in the app folder to try again).",
         {{"all", "Música e sons", "Music and sounds"}, {"sounds", "Só sons", "Sounds only"}, {"off", "Desligado", "Off"}}, 0},
        {"menu_volume", Group::System, "Volume do menu", "Menu volume",
         "O volume da música e dos sons do menu (não é o do jogo).",
         "The volume of the menu's music and sounds (not the game's).",
         {{"20", "20%", "20%"}, {"35", "35%", "35%"}, {"50", "50%", "50%"}, {"70", "70%", "70%"}, {"100", "100%", "100%"}}, 2},
        {"region", Group::System, "Região da emulação", "Emulation region",
         "A região do console que o jogo enxerga. Use a do seu jogo se ele reclamar de região ou abrir com idioma ou conteúdo errados.",
         "The console region the game sees. Use your game's own if it complains about region or opens with the wrong language or content.",
         {{"japan", "Japão", "Japan"}, {"usa", "EUA", "USA"}, {"europe", "Europa", "Europe"}, {"australia", "Austrália", "Australia"},
          {"china", "China", "China"}, {"korea", "Coreia", "Korea"}, {"taiwan", "Taiwan", "Taiwan"}}, 1},
        // 0.9.1. Eden already has one input per player slot (port 0-3); this decides how many of them get a DualShock.
        {"players", Group::Controls, "Controles (jogadores)", "Controllers (players)",
         "Quantos controles o jogo recebe, de 1 a 4. O controle do jogador 1 é o de sempre. Os jogadores 2 a 4 são os outros usuários logados no console: ligue o segundo DualShock, aperte o botão PS e entre como convidado; o app procura a cada 2 segundos e acende a luz do controle (vermelho, verde, rosa). Com 1 (padrão) nada muda. O menu do jogo (L3 + R3) continua só do controle 1. Vale na próxima partida. Ligação do lado do Eden ainda não testada no console.",
         "How many controllers the game is given, 1 to 4. Player 1's controller is the usual one. Players 2 to 4 are the other users logged in to the console: turn on the second DualShock, press the PS button and join as a guest; the app looks every 2 seconds and lights the controller (red, green, pink). With 1 (the default) nothing changes. The in-game menu (L3 + R3) stays with controller 1 only. Applies on the next game start. The Eden-side connection has not been tested on the console yet.",
         {{"1", "1 jogador (padrão)", "1 player (default)"}, {"2", "2 jogadores", "2 players"}, {"3", "3 jogadores", "3 players"},
          {"4", "4 jogadores", "4 players"}}, 0},
    };
    // 0.9.5: the controller model each player is given (what the GAME sees: a Pro Controller, two Joy-Con, ...). "auto" leaves
    // Eden's own default, so nothing changes until a model is picked in the CONTROLS tab.
    static const char* const type_keys[4] = {"player1_type", "player2_type", "player3_type", "player4_type"};
    static const char* const type_label_pt[4] = {"Modelo do controle do jogador 1", "Modelo do controle do jogador 2", "Modelo do controle do jogador 3", "Modelo do controle do jogador 4"};
    static const char* const type_label_en[4] = {"Player 1 controller model", "Player 2 controller model", "Player 3 controller model", "Player 4 controller model"};
    for (int n = 0; n < 4; ++n) {
        list.push_back({type_keys[n], Group::Controls, type_label_pt[n], type_label_en[n],
                        "O controle que o JOGO enxerga (o seu DualShock continua o mesmo). Automático deixa o padrão do Eden. Alguns jogos só aceitam um modelo: Pro Controller serve para quase todos; Portátil serve para jogos que pedem o console no modo portátil; os Joy-Con soltos servem para jogos de dois jogadores com um Joy-Con cada. Vale na próxima partida.",
                        "The controller the GAME sees (your DualShock stays the same). Automatic leaves Eden's default. Some games only take one model: Pro Controller suits almost every game; Handheld is for games that want the console in handheld mode; single Joy-Con suit two-player games with a Joy-Con each. Applies on the next game start.",
                        {{"auto", "Automático (padrão do Eden)", "Automatic (Eden's default)"}, {"pro", "Pro Controller", "Pro Controller"},
                         {"dual", "Dois Joy-Con", "Dual Joy-Con"}, {"left", "Joy-Con esquerdo", "Left Joy-Con"},
                         {"right", "Joy-Con direito", "Right Joy-Con"}, {"handheld", "Portátil", "Handheld"}},
                        0});
    }
    return list;
    }();
    return catalog;
}

Tier TierOf(std::string_view key) {
    // Mandatory: the default is what this port needs; showing a switch only lets a game break.
    static constexpr std::string_view mandatory[] = {
        "jit_page_reuse", "jit_direct_table", "arena_align",                 // the JIT pack and the arena placement (on; safe mode switches them off after deaths)
        "bgra", "a2b10", "rg", "swizzle", "colour_swap",                     // the colour fixes of the video output
        "overlay_draw", "overlay_mode", "overlay_poll", "overlay_flip_stamp", "overlay_delay", // the HUD's own timing
        "dyna_state", "vertex_input_dynamic", "dma_accuracy", "sync_memory", // driver and GPU switches that must follow the console
        "driver_cache", "shader_preload",                                    // shader cache plumbing
        "env:ORBIS_ARENA_MIB", "env:ORBIS_VRAM_GARLIC", "memory_action", // memory plumbing: the memory profile decides (sysflex_mib is back in the menu since the third zip: games differ)
    };
    // Experimental: only in the test builds.
    static constexpr std::string_view experimental[] = {
        "cpu_clock", "cpu_ticks", "astc", "astc_recompress", "async_presentation", "skip_cpu_invalidation", "auto_stub", "profile", "jit_cache_commit",
    };
    for (const std::string_view k : mandatory) {
        if (k == key) {
            return Tier::Mandatory;
        }
    }
    for (const std::string_view k : experimental) {
        if (k == key) {
            return Tier::Experimental;
        }
    }
    return Tier::Normal;
}

bool GlobalOnly(std::string_view key) {
    static constexpr std::string_view global[] = {"language", "menu_theme", "menu_audio", "menu_volume", "covers", "show_advanced", "memory_profile"};
    for (const std::string_view k : global) {
        if (k == key) {
            return true;
        }
    }
    return false;
}

bool PerGameOffered(const Option& option) {
    const std::string_view key = option.key;
    if (GlobalOnly(key) || TierOf(key) == Tier::Mandatory) {
        return false;
    }
    static constexpr std::string_view app_wide[] = {"shader_cache", "shader_notice", "hud_size", "hud_position", "overlay"};
    for (const std::string_view k : app_wide) {
        if (k == key) {
            return false;
        }
    }
    return option.group != Group::System || key == "region";
}

const std::vector<Preset>& Presets() {
    // These name only what each option means (more speed, or more fidelity). They are ways to try a
    // game quickly, not a promise that it will open.
    static const std::vector<Preset> presets = {
        {"Padrão", "Default",
         "Todas as opções de vídeo e CPU nos valores desta versão.",
         "Every video and CPU option at this version's values.",
         {}},
        {"Leve (mais velocidade)", "Light (more speed)",
         "Resolução 0,75x, GPU de precisão baixa, sem flush reativo, shaders assíncronos, ASTC pela CPU e VRAM conservadora. Menos qualidade, mais velocidade.",
         "0.75x resolution, low GPU accuracy, no reactive flushing, async shaders, ASTC on the CPU and conservative VRAM. Less quality, more speed.",
         {{"bgra", "auto"}, {"resolution", "0.75"}, {"gpu_accuracy", "low"}, {"reactive_flushing", "off"}, {"async_shaders", "on"},
          {"astc", "cpu"}, {"vram", "conservative"}}},
        {"Compatibilidade (mais fiel)", "Compatibility (more faithful)",
         "GPU de precisão alta, flush reativo, CPU automática, sem estado dinâmico nem entrada de vértices dinâmica, shaders síncronos. Mais lento, usa menos extensões arriscadas do driver.",
         "High GPU accuracy, reactive flushing, auto CPU accuracy, no dynamic state or dynamic vertex input, synchronous shaders. Slower, uses fewer risky driver extensions.",
         {{"bgra", "auto"}, {"gpu_accuracy", "high"}, {"reactive_flushing", "on"}, {"cpu_accuracy", "auto"}, {"dyna_state", "0"},
          {"vertex_input_dynamic", "off"}, {"async_shaders", "off"}}},
        {"Economia de RAM", "Save RAM",
         "Resolução 0,75x, arena de vídeo de 1152 MiB, VRAM conservadora, cache de shaders carregado até ~32 MiB (o que passar é guardado, não apagado), sem cache do driver, perfil de memória apertado e pausa do jogo quando a memória ficar crítica. Menos memória usada, para jogos que não abrem ou travam por falta dela.",
         "0.75x resolution, 1152 MiB video arena, conservative VRAM, shader cache loaded up to ~32 MiB (what is over is kept, not deleted), no driver cache, the tight memory profile and a pause when memory turns critical. Less memory used, for games that do not open or hang for lack of it.",
         {{"resolution", "0.75"}, {"env:ORBIS_ARENA_MIB", "1152"}, {"vram", "conservative"}, {"shader_preload", "1024"}, {"driver_cache", "off"},
          {"astc", "cpu"}, {"memory_profile", "tight"}, {"memory_action", "pause"}}},
        {"Mais memória de vídeo", "More video memory",
         "Arena de vídeo de 1792 MiB. Sobra menos memória para o jogo: use se aparecer erro de memória de vídeo.",
         "1792 MiB video arena. Less memory is left for the game: use it if video-memory errors show up.",
         {{"env:ORBIS_ARENA_MIB", "1792"}}},
        // 0.7.7: for the Super Mario Maker 2 themes that came out blurred or flat. The cause is NOT known
        // (the video shows sprites alternating between sharp and flat); this is the list of things that make
        // the GPU side more faithful at a cost in speed, to be tried one profile at a time against the others.
        {"Gráficos exatos (teste)", "Exact graphics (test)",
         "Para gráficos errados (texturas borrosas ou chapadas, como nos temas do Super Mario Maker 2): GPU de precisão alta, flush reativo, DMA seguro, memória sincronizada, shaders síncronos e as texturas de volta para fora da arena do driver. Mais lento. A causa ainda não foi confirmada; serve para comparar com os outros perfis.",
         "For wrong graphics (blurred or flat textures, as in Super Mario Maker 2's themes): high GPU accuracy, reactive flushing, safe DMA, synchronised memory, synchronous shaders and textures back outside the driver's arena. Slower. The cause is not confirmed yet; it is for comparing with the other profiles.",
         {{"gpu_accuracy", "high"}, {"reactive_flushing", "on"}, {"dma_accuracy", "safe"}, {"sync_memory", "on"}, {"async_shaders", "off"},
          {"env:ORBIS_VRAM_GARLIC", "1"}}},
        // 0.8.2. Neither of these has been run on a console: they are lists of options picked for what each one should
        // do (see the descriptions), to be compared with Default one game at a time.
        {"Mais FPS (teste)", "More FPS (test)",
         "Para jogos presos na CPU (o caso do Super Mario Maker 2): resolução 0,75x, GPU de precisão baixa, sem flush reativo nem memória sincronizada, ignora invalidações internas da CPU, mostra os quadros por uma thread separada e usa um cache do JIT de 128 MiB por núcleo (até 512 MiB de memória direta nos 4 núcleos, tomados conforme o código cresce; o reaproveitamento de busca de página e a tabela direta do JIT já vêm ligados desde a 0.9.5). Sem filtros extras. Não promete mais FPS: GPU leve ajuda pouco quando a CPU é o limite. Se o jogo travar ao abrir, o modo seguro desliga o que é experimental na partida seguinte.",
         "For CPU-bound games (Super Mario Maker 2's case): 0.75x resolution, low GPU accuracy, no reactive flushing or synchronised memory, skips inner CPU invalidations, shows frames from a separate thread and uses a 128 MiB JIT cache per core (up to 512 MiB of direct memory over the 4 cores, taken as the code grows; the JIT's page lookup reuse and direct table have been on by default since 0.9.5). No extra filters. It does not promise more FPS: a light GPU helps little when the CPU is the limit. If the game hangs while opening, safe mode turns the experimental parts off for the next start.",
         {{"resolution", "0.75"}, {"gpu_accuracy", "low"}, {"reactive_flushing", "off"}, {"sync_memory", "off"}, {"skip_cpu_invalidation", "on"},
          {"async_presentation", "on"}, {"anti_aliasing", "none"}, {"anisotropy", "default"}, {"scaling_filter", "bilinear"}, {"astc", "cpu"},
          {"jit_cache_mib", "128"}}},
        {"RAM mínima (teste)", "Minimum RAM (test)",
         "O mais econômico que não deixa o jogo feio demais: resolução 0,5x (as imagens da GPU, que ficam fora da arena, ocupam um quarto), texturas ASTC guardadas em BC3 (1/4 da memória), arena de vídeo de 1152 MiB, VRAM conservadora, cache de shaders carregado até ~8 MiB (o que passar é guardado, não apagado), sem cache do driver, perfil de memória apertado, pausa do jogo quando a memória ficar crítica e menu de jogos só com miniaturas, e a RAM do jogo usa até 2048 MiB da memória flexível do sistema (o que o pool tiver, menos 128 MiB; ideia do Eden4). A imagem fica bem mais mole.",
         "The most frugal setting that does not make the game too ugly: 0.5x resolution (GPU images, which live outside the arena, take a quarter), ASTC textures kept as BC3 (1/4 of the memory), 1152 MiB video arena, conservative VRAM, shader cache loaded up to ~8 MiB (what is over is kept, not deleted), no driver cache, the tight memory profile, a pause when memory turns critical and the game list with thumbnails only, and the game's RAM uses up to 2048 MiB of the system flexible memory (what the pool has, less 128 MiB; an idea from Eden4). The picture gets much softer.",
         {{"resolution", "0.5"}, {"env:ORBIS_ARENA_MIB", "1152"}, {"vram", "conservative"}, {"shader_preload", "256"}, {"driver_cache", "off"},
          {"astc", "cpu"}, {"astc_recompress", "bc3"}, {"memory_profile", "tight"}, {"memory_action", "pause"}, {"covers", "thumbs"},
          {"sysflex_mib", "2048"}}},
    };
    return presets;
}

const Option* FindOption(std::string_view key) {
    for (const Option& option : Catalog()) {
        if (key == option.key) {
            return &option;
        }
    }
    return nullptr;
}

SettingsFile::Line SettingsFile::Parse(const std::string& raw) {
    Line line{raw, {}, {}};
    // The same reading as main.cpp's ApplySettingsFile: no '\r', no comment, no spaces.
    std::string text = raw;
    text.erase(std::remove(text.begin(), text.end(), '\r'), text.end());
    if (const auto hash = text.find('#'); hash != std::string::npos) {
        text.erase(hash);
    }
    text.erase(std::remove(text.begin(), text.end(), ' '), text.end());
    const auto eq = text.find('=');
    if (text.empty() || eq == std::string::npos || eq == 0) {
        return line;
    }
    line.key = text.substr(0, eq);
    line.value = text.substr(eq + 1);
    if (line.key == "env") {
        const auto split = line.value.find('=');
        if (split == std::string::npos || split == 0) {
            line.key.clear();
            line.value.clear();
        } else {
            line.key = "env:" + line.value.substr(0, split);
            line.value = line.value.substr(split + 1);
        }
    }
    return line;
}

SettingsFile::SettingsFile(const std::string& text) {
    size_t start = 0;
    while (start < text.size()) {
        const auto end = text.find('\n', start);
        const std::string raw = text.substr(start, end == std::string::npos ? end : end - start);
        lines_.push_back(Parse(raw));
        if (end == std::string::npos) {
            break;
        }
        start = end + 1;
    }
}

std::string SettingsFile::Text() const {
    std::string out;
    for (const Line& line : lines_) {
        out += line.raw;
        out += '\n';
    }
    return out;
}

std::string SettingsFile::Get(std::string_view key) const {
    for (const Line& line : lines_) {
        if (line.key == key) {
            return line.value;
        }
    }
    return {};
}

void SettingsFile::Set(std::string_view key, std::string_view value) {
    std::string raw;
    if (key.substr(0, 4) == "env:") {
        raw = "env=" + std::string(key.substr(4)) + "=" + std::string(value);
    } else {
        raw = std::string(key) + "=" + std::string(value);
    }
    for (Line& line : lines_) {
        if (line.key == key) {
            line = Parse(raw);
            return;
        }
    }
    if (lines_.empty()) {
        lines_.push_back(Parse(HeaderComment));
    }
    lines_.push_back(Parse(raw));
}

void SettingsFile::Erase(std::string_view key) {
    lines_.erase(std::remove_if(lines_.begin(), lines_.end(),
                                [&](const Line& line) { return line.key == key; }),
                 lines_.end());
}

int SettingsFile::ChoiceIndex(const Option& option) const {
    const std::string value = Get(option.key);
    for (size_t i = 0; i < option.choices.size(); ++i) {
        if (value == option.choices[i].value) {
            return int(i);
        }
    }
    return option.default_index;
}

void SettingsFile::SetChoice(const Option& option, int index) {
    if (index == option.default_index) {
        Erase(option.key);
    } else {
        Set(option.key, option.choices[size_t(index)].value);
    }
}

bool SettingsFile::IsDefault(const Option& option) const {
    return ChoiceIndex(option) == option.default_index;
}

int SettingsFile::OverrideIndex(const Option& option) const {
    const std::string value = Get(option.key);
    if (value.empty()) {
        return -1;
    }
    for (size_t i = 0; i < option.choices.size(); ++i) {
        if (value == option.choices[i].value) {
            return int(i);
        }
    }
    return -1; // a value this menu does not offer (written by hand): shown as left to the global settings, and kept until changed
}

void SettingsFile::SetOverride(const Option& option, int index) {
    if (index < 0 || index >= int(option.choices.size())) {
        Erase(option.key);
    } else {
        Set(option.key, option.choices[size_t(index)].value);
    }
}

bool SettingsFile::HasSettings() const {
    for (const Line& line : lines_) {
        if (!line.key.empty()) {
            return true;
        }
    }
    return false;
}

std::vector<std::pair<std::string, std::string>> SettingsFile::Entries() const {
    std::vector<std::pair<std::string, std::string>> out;
    for (const Line& line : lines_) {
        if (!line.key.empty()) {
            out.emplace_back(line.key, line.value);
        }
    }
    return out;
}

void SettingsFile::ResetAll() {
    for (const Option& option : Catalog()) {
        if (option.group != Group::System) {
            Erase(option.key);
        }
    }
}

namespace {

/// Index of `value` among the option's choices; the default when it is not one of them.
int ChoiceOf(const Option& option, std::string_view value) {
    for (size_t i = 0; i < option.choices.size(); ++i) {
        if (value == option.choices[i].value) {
            return int(i);
        }
    }
    return option.default_index;
}

} // Anonymous namespace

int SettingsFile::MatchPreset() const {
    // Every option any profile touches must be what the profile says, or its default.
    const auto& presets = Presets();
    for (size_t p = 0; p < presets.size(); ++p) {
        bool matches = true;
        for (const Preset& any : presets) {
            for (const auto& [key, ignored] : any.values) {
                (void)ignored;
                const Option* option = FindOption(key);
                int expected = option->default_index;
                for (const auto& [pk, pv] : presets[p].values) {
                    if (std::string_view(pk) == key) {
                        expected = ChoiceOf(*option, pv);
                    }
                }
                matches = matches && ChoiceIndex(*option) == expected;
            }
        }
        if (matches) {
            return int(p);
        }
    }
    return -1;
}

void SettingsFile::ApplyPreset(int index) {
    const auto& presets = Presets();
    for (const Preset& any : presets) {
        for (const auto& [key, ignored] : any.values) {
            (void)ignored;
            Erase(key);
        }
    }
    for (const auto& [key, value] : presets[size_t(index)].values) {
        const Option* option = FindOption(key);
        SetChoice(*option, ChoiceOf(*option, value));
    }
}

Lang SettingsFile::Language() const {
    return Get("language") == "en" ? Lang::En : Lang::Pt;
}

} // namespace Menu
