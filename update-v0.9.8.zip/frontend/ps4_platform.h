// SPDX-License-Identifier: GPL-3.0-or-later
// eden-ps4: the console-facing pieces of the frontend (boot log, crash reports, system modules,
// the DualShock 4). Kept apart from Eden's headers so the SDK's own headers stay in one file.

#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace Ps4 {

/// Every directory the frontend uses, created on start.
inline constexpr const char* DataDir = "/data/edenps4";

/// Opens /data/edenps4/boot.log (the previous one becomes boot.old.log). Runs from a static
/// constructor before main; calling it again does nothing.
void OpenBootLog();
/// The last `max_lines` lines logged in this session (kept in memory, so they can be shown even
/// when boot.log cannot be written).
std::vector<std::string> RecentLog(size_t max_lines);
/// Starts the frame watchdog thread (see ArmHangWatch).
void StartWatchdog();
/// The sampling profiler (on by default): busy share and hottest code of the GPU, Vulkan and
/// CPU-core threads every 30 s in boot.log.
void SetProfiling(bool enabled);
/// One line in boot.log, flushed and synced before returning (a crash right after keeps it).
void Log(const char* fmt, ...) __attribute__((format(printf, 1, 2)));

/// Lazy-memory fault handler + crash report for every other fault, and the orbis-compat log
/// (RADV, the overlay) into boot.log.
void InstallCrashReporting();
/// 0.9.7 fix 2: creates `path` empty and keeps it open; a crash (or a fatal error of the driver) writes a line into it before anything else is logged, and safe mode reads
/// that (safe_mode.h). Null or empty: none.
void SetCrashMarker(const char* path);
/// Names the current phase for crash and hang reports.
void SetPhase(const char* phase);
/// The watchdog: if the frame counter stops for `seconds` while a game runs, the main thread's
/// stack is dumped to boot.log (no restart). 0 disables it.
void ArmHangWatch(unsigned seconds);
/// Records the calling thread under `name` for hang stack dumps.
void RegisterThread(const char* name);
/// 0.9.6: one line in boot.log with what the CPU says it can do (SSE4.2, AVX and whether the system saves AVX state, F16C, BMI1...). The JIT
/// (Dynarmic) picks its SSE/AVX forms of the Switch's NEON instructions from the same answers; this makes the premise visible.
void LogCpuFeatures();
/// 0.9.6: cpu_affinity (thread_placement.h). `enabled` false: every thread stays where the system puts it. True: asks the console which
/// cores this process may use (from the calling thread, the main one, before any game thread exists), and if it can tell and there are at
/// least five, every thread that Eden names afterwards goes to the core or cores the plan gives it. Logs what it found and decided.
void ConfigureThreadPlacement(bool enabled);
/// Called for every thread Eden names (see EdenPs4OnThreadNamed), by that thread: applies the plan to it.
void PlaceCurrentThread(const char* name);
/// Called by the presentation path for every frame shown.
void NoteFrame();
/// 0.8.1: the sampling profiler normally reports every 30 s. This asks it to start a fresh window (`report` false) or to
/// write the window so far to boot.log and start another (`report` true), so a stall of a few seconds gets a profile of
/// its own. Asynchronous: the profiler thread does it within a few milliseconds.
void ProfileWindow(bool report);

/// Starts the app again from its executable, so it opens on the game list (the way "Exit game" gets
/// back to the menu: Eden cannot be torn down and rebuilt inside one run, a new process can). Returns
/// only if the system refused or the SDK cannot do it; the caller then keeps the app idle.
bool RestartApp();
/// 0.7.7 fix: call once at start. If the last run asked the system to start the app again, judge from the time
/// that went by whether that way worked (restart_state.txt), so the next restart uses a way that does.
void NoteRestartOutcome();

/// 0.7.7: ends the app for good (the way out when RestartApp() found no way to start it again).
[[noreturn]] void QuitApp();

/// 0.7.7: limits what std::thread::hardware_concurrency() answers (0 lifts the limit). Eden sizes its
/// shader builder pool from it, so this must be set before the game is loaded.
void SetWorkerCap(unsigned threads);
/// How many times hardware_concurrency() was asked and how many answers were cut by the cap.
void WorkerCapStats(unsigned* asked, unsigned* capped);

/// System modules the SDK does not load by itself (pad, user service, audio out...).
void LoadSystemModules();
void HideSplashScreen();

struct PadState {
    bool connected{};
    std::uint32_t buttons{};
    std::uint8_t lx{128}, ly{128}, rx{128}, ry{128};
    std::uint8_t l2{}, r2{};
};

/// Opens the first user's controller. False if there is none.
bool OpenPad();
inline constexpr int MaxPads = 4;
/// `index` 0 is the first user's controller; 1-3 are controllers 2-4 (0.9.1), see OpenExtraPads. A controller that is
/// not open or not connected reads as `connected == false`.
PadState ReadPad(int index = 0);
/// 0.9.1: opens the controllers of the other users who are logged in (a second controller logs in as a guest when its
/// PS button is pressed), up to `wanted` pads in all. Cheap to call every frame: it scans every 2 seconds at most.
/// Returns how many pads this call opened.
int OpenExtraPads(int wanted);
/// How many controllers are open now (the first one included).
int PadsOpen();
void SetPadLight(std::uint8_t r, std::uint8_t g, std::uint8_t b);

// DualShock 4 button bits (scePad).
namespace Button {
inline constexpr std::uint32_t L3 = 0x0002;
inline constexpr std::uint32_t R3 = 0x0004;
inline constexpr std::uint32_t Options = 0x0008;
inline constexpr std::uint32_t Up = 0x0010;
inline constexpr std::uint32_t Right = 0x0020;
inline constexpr std::uint32_t Down = 0x0040;
inline constexpr std::uint32_t Left = 0x0080;
inline constexpr std::uint32_t L2 = 0x0100;
inline constexpr std::uint32_t R2 = 0x0200;
inline constexpr std::uint32_t L1 = 0x0400;
inline constexpr std::uint32_t R1 = 0x0800;
inline constexpr std::uint32_t Triangle = 0x1000;
inline constexpr std::uint32_t Circle = 0x2000;
inline constexpr std::uint32_t Cross = 0x4000;
inline constexpr std::uint32_t Square = 0x8000;
inline constexpr std::uint32_t TouchPad = 0x100000;
} // namespace Button

/// Monotonic microseconds.
std::uint64_t NowUs();

/// Direct and flexible memory still free, for the periodic status line.
std::uint64_t FreeDirectMemory();

/// All the direct memory the console gives this process, in bytes (4608 MiB on the PS4 Pro that was
/// measured). 0.7.6: the memory profile (memory_guard.h) is chosen from it.
std::uint64_t DirectMemoryTotal();

/// 0.9.0: lets the game's lazily committed memory (guest RAM and Eden's tables) take up to `cap_mib` MiB from the
/// console's system flexible pool instead of direct memory (0 = off, the default). It finds the kernel call, probes
/// how much of the pool is free, keeps a reserve for the system (memory_guard.h) and logs what it decided; if the
/// call is missing or the pool is empty nothing changes and everything stays in direct memory. Call it before the
/// first guest memory is touched.
void ConfigureSystemFlexible(std::uint64_t cap_mib);
/// 0.9.6: the budget ConfigureSystemFlexible settled on, in MiB (0 when the pool is off or not available).
std::uint64_t SystemFlexibleBudgetMiB();

} // namespace Ps4
