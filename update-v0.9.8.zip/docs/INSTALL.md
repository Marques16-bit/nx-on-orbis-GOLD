# Installing

Tested only on a **PS4 Pro, firmware 12.02, GoldHEN**. Other firmwares or a base PS4 may or may not
work (a base PS4 would also be slower). Read the [README](../README.md) first: this is an experiment, games
run but slowly, and some close when the console runs out of memory.

Do the steps in this order: the files go on the console **before** the package is installed, so
the first start already finds them.

## What you need

| File | Where it comes from | Where it goes on the PS4 |
| --- | --- | --- |
| `prod.keys` (and `title.keys` if you have it) | dumped **from your own Switch** with Lockpick_RCM | `/data/edenps4/keys/` |
| the firmware `.nca` files | dumped **from your own Switch** (TegraExplorer / NXDumpTool) | `/data/edenps4/firmware/` |
| your games, `.nsp` or `.xci` | your own cartridges or eShop purchases | `/data/edenps4/roms/` |
| `nx-on-orbis-v<version>.pkg` | the Releases page of this repository | installed as a package |

Nothing of the above is included in this project, and nobody here can provide it.

Without keys and firmware the bundled Homebrew Menu still runs, which is a quick way to check the
port itself works on your console.

## Step 1: copy your files over FTP

1. On the PS4, with GoldHEN loaded: *Settings → GoldHEN → Server Settings → Enable FTP Server*.
   Note the console's IP address.
2. In FileZilla connect to that IP, port **2121**, with empty user name and password, and set
   *Transfer → Transfer type → Binary* (text mode damages binary files).
3. Create the folders `/data/edenps4/keys`, `/data/edenps4/firmware` and `/data/edenps4/roms`.
4. Upload, in binary mode, `prod.keys` (and `title.keys`) to `keys/`, the firmware `.nca` files to `firmware/` and
   your games to `roms/`. The names must stay exactly as dumped (`prod.keys`, not `prod.keys.txt`).
5. Upload the package to `/data/pkg/`, also in binary mode (create it if needed), or put it on a USB drive.

## Step 2: install the package

*Settings → GoldHEN → Package Installer* (or *Debug Settings → Game → Package Installer*), pick
`nx-on-orbis-v<version>.pkg` and install it. It appears as **NX on Orbis** (title ID `EDPS00001`).
Installing a newer package over it keeps everything in `/data/edenps4/`.

## Step 3: play

1. Start **NX on Orbis**. The first start copies the firmware into its emulated system memory,
   which takes a moment.
2. The menu opens (below). Pick a game with Up/Down and press Cross.
3. The first runs of a game stutter while shaders compile; they are cached for later runs.

### The menu

The tabs are a column on the left (0.9.7 fix 4) and L1/R1 walk it: **Games**, **Controls**, **Video**, **CPU and memory**, **HUD**, **System**, **Log**, **Tests** (the last two are not in the public build). In the
settings tabs Up/Down choose an option, Left/Right (or Cross) change its value, Triangle restores
its default, Circle goes back to the games. OPTIONS plays the last game highlighted, from any tab.
A value shown in teal with a dot is not the default. Changes are saved at once in `settings.txt` and
apply to the game that starts next. The System tab changes the menu's language (Portuguese or
English), restores every default, and shows whether `prod.keys` and the firmware were found, which
is the first thing to look at when a game does not start. The last entry of the Games tab is the
built-in Homebrew Menu, a test that needs no game.

Controls (Switch layout by position): Circle = A, Cross = B, Triangle = X, Square = Y, L1/R1 = L/R,
L2/R2 = ZL/ZR, Options = +, touch pad click = -, L3/R3 = sticks. Hold **Options + touch pad for 2
seconds** to quit.

## Optional files

| File in `/data/edenps4/` | Effect |
| --- | --- |
| `updates/` | update and DLC `.nsp` files, applied when the game starts |
| `game.txt` | full path of a game to start directly |
| `nomenu.txt` (empty) | skip the menu and start the last game played |
| `settings.txt` | overrides, one `key=value` per line (below) |

Every `settings.txt` key, its values (the default marked), and the quick profiles are in [SETTINGS.md](SETTINGS.md), generated from the
menu itself, so it is always what this version does. The menu writes the file; edit it by hand only for what the menu does not show,
for example `env=NAME=VALUE` (an environment variable for the GPU driver, such as `env=ORBIS_ARENA_MIB=1280`).

## The data folder, FTP and the Homebrew Menu

- The app makes every folder it needs the first time it opens (`keys`, `firmware`, `roms`,
  `updates`, `nand`, `sdmc`, ...) and a `LEIA-ME.txt`. Fill `keys`, `firmware` and `roms` with the
  files dumped from **your own** Switch. If FTP or a file manager still cannot write or delete in
  `/data/edenps4`, open the app once more (it opens the permissions of what is there) and see the
  SYSTEM tab: the "Writing" line says whether the app itself can write.
- **PERFORMANCE tab:** the HUD, the shader preload, the video overlay and "draw over the game". If a game shows a black screen or glitches, turn "Draw the HUD and menu over the game" off first; then "Video overlay".
- **In a game:** L3 + R3 together open the pause menu (Continue, HUD, speed limit, Exit game); the HUD (FPS, CPU cores, memory, temperature) is also an option in the ADVANCED tab. If the colours are swapped, "Swap red and blue on the screen" is in the same tab.
- **Shader cache:** Eden keeps one per game in `cache/shader/<title id>/`; the SYSTEM tab shows its size and can clear it. At start only the first 256 cached shaders are compiled (VIDEO tab, "Preload shaders at start"); the rest compile while you play. If a game stops opening, clear the cache (SYSTEM tab) or delete `cache/shader/<title id>` over FTP.
- **Firmware:** copy the `.zip` as it is found (or the `.nca` files) into `firmware/`; it is installed when a game starts, and the SYSTEM tab says whether it was found.
- The menu's **LOG** tab shows the end of the last session's log on the TV; after a crash, open the
  app again and photograph it.
- "Emulator test (Homebrew Menu)" ends in `Error: launchInit() failed`. That is **expected**: the
  Homebrew Menu needs the Switch's own loader. If you see it, the emulator started and draws.

## Troubleshooting

Everything is logged to `/data/edenps4/boot.log` (the previous run is `boot.old.log`). Download it
before starting the app again.

| Line in `boot.log` | Meaning |
| --- | --- |
| `missing /data/edenps4/keys/prod.keys - dump it from your Switch` | the keys are not where step 1 puts them, or the file name differs |
| `no firmware/ folder; games that need the firmware will not start` | the firmware folder is missing |
| `firmware: N NCAs installed now, ... M failed` | some firmware files could not be copied (damaged or incomplete dump) |
| `no game: put an .nsp or .xci in /data/edenps4/roms` | no game found: the Homebrew Menu starts instead |
| `!! CRASH ...` followed by `eboot+0x...` lines | a crash; symbolize the offsets with the release's ELF: `llvm-symbolizer --obj=<that build's ELF> -C -f 0x<offset>` |

Other logs: `/data/edenps4/mesa.log` (GPU driver) and `/data/edenps4/log/eden_log.txt` (Eden).

Please do not send reports about this port to the Eden project.
