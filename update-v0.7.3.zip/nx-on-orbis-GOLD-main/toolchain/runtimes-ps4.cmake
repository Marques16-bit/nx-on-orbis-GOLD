# Toolchain for building LLVM 18 libc++/libc++abi for the PS4 (OpenOrbis musl + orbis-compat).
# Only static libraries are produced, so try_compile never links.
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR x86_64)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
# Where things live. The CI (and anyone building off Windows) sets NXO_ROOT to this repository;
# without it the defaults are the original author's Windows machine.
if(DEFINED ENV{NXO_ROOT})
  set(NXO_ROOT "$ENV{NXO_ROOT}")
else()
  set(NXO_ROOT "C:/Users/alejo/eden-ps4")
endif()
if(DEFINED ENV{NXO_LLVM_BIN})   # CI / Linux: clang 18, e.g. /usr/lib/llvm-18/bin
  set(LLVMBIN "$ENV{NXO_LLVM_BIN}")
else()
  set(LLVMBIN "C:/Users/alejo/soh-ps4/tools/llvm/bin")
endif()
if(CMAKE_HOST_WIN32)
  set(EXE ".exe")
else()
  set(EXE "")
endif()
set(SDK "${NXO_ROOT}/sdk-dl/orbis-sdk-v1/sdk")
set(COMPAT "${NXO_ROOT}/sdk-dl/orbis-sdk-v1/orbis-compat")
set(CMAKE_C_COMPILER "${LLVMBIN}/clang${EXE}")
set(CMAKE_CXX_COMPILER "${LLVMBIN}/clang++${EXE}")
set(CMAKE_ASM_COMPILER "${LLVMBIN}/clang${EXE}")
set(CMAKE_AR "${LLVMBIN}/llvm-ar${EXE}")
set(CMAKE_RANLIB "${LLVMBIN}/llvm-ranlib${EXE}")
set(CMAKE_C_COMPILER_TARGET x86_64-pc-freebsd12-elf)
set(CMAKE_CXX_COMPILER_TARGET x86_64-pc-freebsd12-elf)
set(CMAKE_ASM_COMPILER_TARGET x86_64-pc-freebsd12-elf)
set(_common "-fPIC -funwind-tables -D__PS4__ -DPS4 -D__ORBIS__ -D_BSD_SOURCE=1 -U__FreeBSD__ -isysroot ${SDK}")
# On a Linux host clang's FreeBSD driver, given no --sysroot, also searches the host's /usr/include:
# __has_include(<linux/random.h>) and configure checks then see Linux headers that do not exist on
# the PS4 (libc++'s random.cpp: "'asm/types.h' file not found"). -nostdlibinc drops the system
# directories and keeps the compiler's own headers plus the -isystem paths below. On Windows there is
# no /usr/include, so the flags stay exactly as they were.
if(NOT CMAKE_HOST_WIN32)
  string(APPEND _common " -nostdlibinc")
endif()
set(OVERLAY "${NXO_ROOT}/toolchain/include-overlay")
set(CMAKE_C_FLAGS_INIT "${_common} -isystem ${OVERLAY} -isystem ${COMPAT}/include -isystem ${SDK}/include -include orbis_prefix.h")
set(CMAKE_CXX_FLAGS_INIT "${_common} -nostdinc++ -isystem ${OVERLAY} -isystem ${COMPAT}/include -isystem ${SDK}/include -include orbis_prefix.h")
set(CMAKE_ASM_FLAGS_INIT "${_common}")
